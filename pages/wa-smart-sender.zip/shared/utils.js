/* =====================================================================
 * utils.js — Chhote helper functions (popup aur content dono use karte hain)
 * ===================================================================== */

var U = {
  sleep: function (ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  },

  randInt: function (a, b) {
    a = Math.ceil(a); b = Math.floor(b);
    return Math.floor(Math.random() * (b - a + 1)) + a;
  },

  /* Human-like gap:
   * - 3 random numbers ka average => "bell curve" (zyada tar beech ki value,
   *   kabhi kabhi kam/zyada) — bilkul insaan jaisa, robot jaisa fixed nahi
   * - 12% chance: extra 15–45 sec "distracted" pause (jaise insaan phone rakh de)
   * - milliseconds bhi random taaki koi pattern na bane
   */
  humanDelayMs: function (minS, maxS) {
    var r = (Math.random() + Math.random() + Math.random()) / 3;
    var s = minS + r * (maxS - minS);
    if (Math.random() < 0.12) s += U.randInt(15, 45);
    return Math.round(s * 1000 + Math.random() * 999);
  },

  /* Message bhejne se pehle "padhne + type karne" jitna samay */
  typingPauseMs: function (text, typingSim) {
    var base = U.randInt(1500, 4000);
    if (!typingSim) return base;
    var perChar = U.randInt(35, 90);
    return base + Math.min(text.length * perChar, 25000);
  },

  /* Spintax: "{Hi|Hello|Namaste} dost" => random ek word */
  spin: function (text) {
    var prev;
    do {
      prev = text;
      text = text.replace(/\{([^{}]*\|[^{}]*)\}/g, function (m, g) {
        var opts = g.split('|');
        return opts[Math.floor(Math.random() * opts.length)];
      });
    } while (text !== prev);
    return text;
  },

  /* Variables: {{name}}, {{city}} ... contact ki values se replace */
  fillVars: function (text, contact) {
    return text.replace(/\{\{\s*([\w]+)\s*\}\}/g, function (m, k) {
      var v = contact[k.toLowerCase()];
      return v === undefined || v === null ? '' : String(v);
    });
  },

  buildMessage: function (template, contact, allowSpin) {
    var t = U.fillVars(template, contact);
    return allowSpin ? U.spin(t) : t;
  },

  /* Number ko international format (sirf digits) me badlo */
  normalizePhone: function (raw, cc) {
    var d = String(raw || '').replace(/\D/g, '');
    if (d.indexOf('00') === 0) d = d.slice(2);
    if (d.length === 11 && d[0] === '0') d = d.slice(1);
    if (d.length === 10 && cc) d = String(cc).replace(/\D/g, '') + d;
    return d.length >= 10 && d.length <= 15 ? d : null;
  },

  /* Contacts text/CSV parse:
   * Bina header:  9876543210, Rahul, Delhi   => phone, name, var1
   * Header ke saath: phone,name,city          => {{city}} bhi use kar sakte ho
   */
  parseContacts: function (text, cc, blocklist) {
    var block = new Set((blocklist || []).map(function (p) { return U.normalizePhone(p, cc); }).filter(Boolean));
    var lines = String(text || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
    var out = { valid: [], invalid: [], dupes: 0, blocked: 0, keys: ['phone', 'name'] };
    if (!lines.length) return out;

    var split = function (l) {
      return l.split(/[,\t;]/).map(function (s) { return s.trim().replace(/^"|"$/g, ''); });
    };

    var first = split(lines[0]);
    var keys, start = 0, pi = 0;
    if (!/\d{5,}/.test(first.join(' '))) {
      keys = first.map(function (k, i) {
        return (k || 'col' + (i + 1)).toLowerCase().replace(/[^\w]+/g, '_');
      });
      pi = keys.findIndex(function (k) { return /phone|mobile|number|whatsapp|contact/.test(k); });
      if (pi < 0) pi = 0;
      keys[pi] = 'phone';
      start = 1;
    } else {
      keys = ['phone', 'name'];
      for (var v = 1; v < 20; v++) keys.push('var' + v);
    }
    out.keys = keys.slice(0, Math.max(2, first.length));

    var seen = new Set();
    for (var i = start; i < lines.length; i++) {
      var cols = split(lines[i]);
      var phone = U.normalizePhone(cols[pi], cc);
      if (!phone) { out.invalid.push(lines[i]); continue; }
      if (seen.has(phone)) { out.dupes++; continue; }
      if (block.has(phone)) { out.blocked++; continue; }
      seen.add(phone);
      var c = {};
      keys.forEach(function (k, idx) { if (cols[idx] !== undefined) c[k] = cols[idx]; });
      c.phone = phone;
      if (!c.name) c.name = '';
      out.valid.push(c);
    }
    return out;
  },

  todayKey: function () {
    var d = new Date();
    return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
  },

  /* Working hours ke andar ka agla allowed time */
  nextAllowedTime: function (ts, startHour, endHour) {
    var d = new Date(ts);
    var h = d.getHours();
    if (h >= startHour && h < endHour) return ts;
    var n = new Date(ts);
    if (h >= endHour) n.setDate(n.getDate() + 1);
    n.setHours(startHour, U.randInt(0, 20), U.randInt(0, 59), 0);
    return n.getTime();
  },

  /* Kal subah (daily limit poora hone par) */
  tomorrowStart: function (startHour) {
    var n = new Date();
    n.setDate(n.getDate() + 1);
    n.setHours(startHour || 9, U.randInt(0, 25), U.randInt(0, 59), 0);
    return n.getTime();
  },

  fmtDuration: function (ms) {
    if (ms <= 0) return '0s';
    var s = Math.round(ms / 1000);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    if (h) return h + 'h ' + m + 'm';
    if (m) return m + 'm ' + sec + 's';
    return sec + 's';
  },

  csvEscape: function (v) {
    v = v === undefined || v === null ? '' : String(v);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
};

if (typeof module !== 'undefined') module.exports = U;
