/* =====================================================================
 * license.js — Premium key ko aapke server (Google Apps Script) se check karna
 * Popup aur background dono ise use karte hain.
 *
 * Suraksha:
 *  - Har computer ka ek random Device ID bana hai. Key pehli baar jis device
 *    par activate hoti hai, server use usi se jod deta hai. Dusre computer par
 *    wahi key nahi chalegi (jab tak aap Sheet me device reset na karein).
 *  - Har 6 ghante background me dobara check hota hai. Aap Sheet me key
 *    "blocked" karenge ya expiry nikal jayegi to premium apne aap band.
 * ===================================================================== */

var LIC = {
  deviceId: async function () {
    var d = (await chrome.storage.local.get('deviceId')).deviceId;
    if (!d) {
      d = crypto.randomUUID();
      await chrome.storage.local.set({ deviceId: d });
    }
    return d;
  },

  call: async function (action, key) {
    if (!WSS.LICENSE_API_URL || WSS.LICENSE_API_URL.indexOf('PASTE') === 0) {
      throw new Error('Server URL set nahi hai (config.js > LICENSE_API_URL)');
    }
    var url = WSS.LICENSE_API_URL +
      '?action=' + encodeURIComponent(action) +
      '&key=' + encodeURIComponent(key) +
      '&device=' + encodeURIComponent(await LIC.deviceId()) +
      '&v=' + encodeURIComponent(WSS.VERSION) +
      '&t=' + Date.now();
    var r = await fetch(url, { redirect: 'follow', cache: 'no-store' });
    if (!r.ok) throw new Error('Server error ' + r.status);
    return r.json();
  },

  saveActive: function (key, res) {
    return chrome.storage.local.set({
      license: {
        key: key,
        status: 'active',
        plan: res.plan || 'premium',
        name: res.name || '',
        expiry: res.expiry || null,
        checkedAt: Date.now(),
        message: ''
      }
    });
  },

  activate: async function (key) {
    key = String(key || '').trim().toUpperCase();
    var res = await LIC.call('activate', key);
    if (res.ok) await LIC.saveActive(key, res);
    return res;
  },

  /* Saved key ko dobara check karo. Internet na ho to purana result 48 ghante chalega. */
  verify: async function () {
    var lic = (await chrome.storage.local.get('license')).license;
    if (!lic || !lic.key) return null;
    try {
      var res = await LIC.call('verify', lic.key);
      if (res.ok) {
        await LIC.saveActive(lic.key, res);
      } else {
        await chrome.storage.local.set({
          license: { key: lic.key, status: res.status || 'invalid', message: res.message || '', checkedAt: Date.now() }
        });
      }
      return res;
    } catch (e) {
      return { ok: false, offline: true, message: e.message };
    }
  },

  /* Is computer se key hatao (taaki customer naye computer par laga sake) */
  deactivate: async function () {
    var lic = (await chrome.storage.local.get('license')).license;
    if (lic && lic.key) {
      try { await LIC.call('deactivate', lic.key); } catch (e) { /* offline: local se hata do */ }
    }
    await chrome.storage.local.remove('license');
  }
};
