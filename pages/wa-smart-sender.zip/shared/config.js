/* =====================================================================
 * config.js — Poore extension ki settings ek jagah
 * - Plans (Free / Premium) ki limits
 * - Default (safe) delay presets
 * - WhatsApp Web ke CSS selectors (WhatsApp UI badle to sirf yahan update karo)
 * - License key check (demo / offline)
 * ===================================================================== */

var WSS = {
  VERSION: '1.1.0',

  // ⚠️ Google Apps Script "Deploy" karne ke baad jo Web App URL mile, yahan paste karo
  // (README ka "Premium Server Setup" section dekho)
  LICENSE_API_URL: 'https://script.google.com/macros/s/AKfycbzbWzVO84pIpp83dlNiiBTUxBwx2dTBl5P0pxmNk8ZOY5y04YXpL64DdeTvvnfFmE12/exec',

  // Internet na mile to premium kitni der tak chalta rahe (48 ghante)
  LICENSE_GRACE_MS: 48 * 60 * 60 * 1000,

  // Kabhi bhi isse kam gap allow nahi hoga (safety floor, seconds)
  MIN_DELAY_FLOOR: 20,

  TIERS: {
    free: {
      id: 'free',
      label: 'Free',
      dailyLimitMax: 50,     // 1 din me max messages
      maxContacts: 100,      // 1 campaign me max contacts
      customDelays: false,   // delay khud set nahi kar sakte (safe preset)
      spintax: false,        // {Hi|Hello} random words
      csvImport: false,
      workingHours: false,
      typingSim: false,
      reportExport: false
    },
    premium: {
      id: 'premium',
      label: 'Premium ⭐',
      dailyLimitMax: 300,
      maxContacts: 5000,
      customDelays: true,
      spintax: true,
      csvImport: true,
      workingHours: true,
      typingSim: true,
      reportExport: true
    }
  },

  // Default settings har plan ke liye (seconds / minutes / hours)
  PRESETS: {
    free: {
      minDelay: 45, maxDelay: 120,       // har message ke baad 45–120 sec random
      batchMin: 8, batchMax: 15,         // har 8–15 messages ke baad break
      breakMin: 5, breakMax: 12,         // break 5–12 minute
      dailyLimit: 50,
      useHours: false, startHour: 9, endHour: 20,
      typingSim: false
    },
    premium: {
      minDelay: 25, maxDelay: 90,
      batchMin: 10, batchMax: 20,
      breakMin: 5, breakMax: 15,
      dailyLimit: 200,
      useHours: true, startHour: 9, endHour: 21,
      typingSim: true
    }
  },

  // WhatsApp Web ke selectors — WhatsApp apna HTML badalta rehta hai.
  // Agar kabhi "send fail" aaye to F12 > Inspect karke yahan naye selectors daalo.
  SELECTORS: {
    appReady: ['#pane-side', '#side', 'div[aria-label="Chat list"]'],
    composeBox: [
      'footer div[contenteditable="true"]',
      'div[contenteditable="true"][data-tab="10"]',
      'div[aria-label="Type a message"]'
    ],
    sendButton: [
      'button[aria-label="Send"]',
      'span[data-icon="send"]',
      'span[data-icon="wds-ic-send-filled"]',
      '[data-testid="send"]'
    ],
    dialog: ['div[role="dialog"]', '[data-animate-modal-popup="true"]'],
    invalidText: /invalid|isn.t on whatsapp|not on whatsapp|अमान्य/i
  }
};

/* ---------- License (server-verified) ----------
 * Key ka asli check Google Sheet server par hota hai (shared/license.js).
 * Yahan sirf save kiye hue result ko dekha jata hai:
 *  - status "active" ho
 *  - expiry date nikli na ho
 *  - pichhle 48 ghante me server se check hua ho
 */
WSS.isPremium = function (lic) {
  if (!lic || lic.status !== 'active') return false;
  var now = Date.now();
  if (lic.expiry && now > lic.expiry) return false;
  if (!lic.checkedAt || now - lic.checkedAt > WSS.LICENSE_GRACE_MS) return false;
  return true;
};

WSS.tierFromLicense = function (license) {
  return WSS.isPremium(license) ? WSS.TIERS.premium : WSS.TIERS.free;
};

if (typeof module !== 'undefined') module.exports = WSS;
