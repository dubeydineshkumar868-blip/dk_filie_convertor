# WA Smart Sender — Chrome Extension (v1.1.0)

WhatsApp Web se **custom message** bhejne ka human-like system:
random time gap, batch breaks, daily limit, working hours, aur **Free / Premium** plans.

---

## 1. Install kaise karein (5 minute)

1. Yeh poora folder `wa-smart-sender` apne computer par unzip karein.
2. Chrome me kholiye: `chrome://extensions`
3. Upar right me **Developer mode** ON karein.
4. **Load unpacked** dabaiye → `wa-smart-sender` folder select karein.
5. Puzzle icon 🧩 se extension ko **pin** kar lijiye.
6. `https://web.whatsapp.com` kholiye aur QR scan karke login karein.

Code me kuch bhi badlo → `chrome://extensions` par extension ka 🔄 reload dabao → WhatsApp tab bhi reload karo.

---

## 2. Use kaise karein

**Contacts** (har line me ek):
```
9876543210, Rahul
9123456780, Priya, Delhi
```
Ya header ke saath (Premium me CSV file bhi import kar sakte ho):
```
phone,name,city,product
9876543210,Rahul,Delhi,Shoes
```
10-digit number ke aage apne aap `91` lag jata hai (Settings me badal sakte ho).
Duplicate, galat aur "do-not-send" wale numbers apne aap hat jate hain.

**Message:**
```
{Hi|Hello|Namaste} {{name}} ji 🙏
{{city}} me aapke liye {{product}} par 20% off hai!
```
- `{{name}}`, `{{city}}` → har contact ki value se badal jayega (Free + Premium)
- `{Hi|Hello|Namaste}` → har message me random ek word (Spintax — Premium).
  Isse har message thoda alag hota hai, sab ek jaise copy-paste nahi lagte.

Phir **Start** dabaiye. WhatsApp tab **khula rakhein** (best: alag window me, minimize mat karo —
Chrome background tabs ke timers dheeme kar deta hai).

---

## 3. "Insaan jaisa" system kaise kaam karta hai

| Feature | Kya karta hai |
|---|---|
| Bell-curve random gap | Har message ke baad alag time (jaise 38s, 71s, 52s…). 3 random numbers ka average, isliye pattern nahi banta |
| "Distracted" pause | 12% chance par extra 15–45 sec ka gap, jaise insaan phone rakh de |
| Batch break | Har 8–15 (random) messages ke baad 5–12 min ka break |
| Typing-time | Chat khulne ke baad send karne se pehle 1.5–4 sec; Premium me lambe message par zyada pause |
| Daily limit | Limit poora → kal subah apne aap resume |
| Working hours | Sirf din ke tay ghanton me bhejna (Premium) |
| Safety floor | Koi bhi 20 sec se kam gap set nahi kar sakta |
| Official link | Chat `web.whatsapp.com/send?phone=…` link se khulta hai, jaise koi link click kare |
| Resume | Page reload / crash ke baad wahin se chalu |

### ⚠️ Sach baat — "number kabhi block nahi hoga" koi guarantee nahi de sakta
WhatsApp ka ban system sirf timing nahi dekhta. Sabse bade kaaran:
1. **Log aapko report/block karte hain** — sabse bada factor.
2. **Unknown numbers ko** message (jinke paas aapka number saved nahi / jinhone kabhi baat nahi ki).
3. **Naya number** jo turant zyada messages bhejne lage.
4. **Ek jaisa message** sabko, bina reply ke.

Isliye safe rehne ke liye:
- Sirf un logon ko bhejo jinhone **aapse judna chaha hai** (customers, enquiry wale).
- Naya number? Pehle 1–2 hafte normal use karo, phir 20–30/day se shuru karke dheere badhao.
- Opt-out line ON rakho aur jo STOP bole unhe **Do-not-send list** me daalo.
- Spintax aur `{{name}}` use karo taaki message personal lage.
- Dhyan rakho: WhatsApp ki Terms automation allow nahi karti, isliye risk hamesha rehta hai.
  Bade business ke liye **WhatsApp Business Platform (official API)** sahi aur safe raasta hai.

---

## 4. Free vs Premium

| | Free | Premium ⭐ |
|---|---|---|
| Messages/day | 50 | 300 |
| Contacts/campaign | 100 | 5,000 |
| Random gap + batch break | Preset (safe) | Custom |
| {{variables}} | ✔ | ✔ |
| Spintax | ✖ | ✔ |
| CSV import | ✖ | ✔ |
| Working hours | ✖ | ✔ |
| Typing simulation | ✖ | ✔ |
| Report CSV export | ✖ | ✔ |

Limits badalni hain? → `shared/config.js` me `TIERS` aur `PRESETS`.

### 🔐 Premium Server Setup (Google Sheet — free, card nahi chahiye)

Keys ab **aapke Google Sheet** se check hoti hain. Koi bhi nakli key nahi bana sakta,
ek key sirf **ek computer** par chalti hai, aur aap kisi bhi waqt key **block / expire** kar sakte ho.

**A. Sheet aur script banao (10 minute, sirf ek baar)**
1. [sheets.new](https://sheets.new) kholo → naam rakho `WA Smart Sender Licenses`.
2. Menu: **Extensions → Apps Script**.
3. Wahan jo code hai use mita do, aur `server/Code.gs` ka poora code paste karo → 💾 Save.
4. Upar function dropdown me `setup` chuno → **▶ Run**.
   Pehli baar Google permission maangega → *Review permissions* → apna account →
   *Advanced* → *Go to project (unsafe)* → *Allow*. (Ye aapka khud ka script hai, isliye ye warning aati hai.)
5. **Deploy → New deployment** → ⚙ icon → **Web app** chuno:
   - Execute as: **Me**
   - Who has access: **Anyone**
   → **Deploy** → jo **Web app URL** mile (`https://script.google.com/macros/s/.../exec`) use copy karo.
6. Extension ke `shared/config.js` me paste karo:
   ```js
   LICENSE_API_URL: 'https://script.google.com/macros/s/XXXXXXX/exec',
   ```
7. `chrome://extensions` → 🔄 reload.

> Code.gs me kabhi badlav karo to: **Deploy → Manage deployments → ✏ Edit → Version: New version → Deploy**
> (URL wahi rahega).

**B. Customer ko key dena**
1. Sheet refresh karo → upar naya menu **🔑 License** dikhega.
2. **🔑 License → ➕ Naya customer key banao** → likho `Rahul, 9876543210, 30`
   (30 = 1 mahina, 365 = 1 saal, 0 = Lifetime).
3. Key popup me dikhegi (`WSS-XXXX-XXXX-XXXX-XXXX`) → customer ko WhatsApp par bhejo.
4. Customer extension ke **Plan** tab me key daal ke **Activate** kare. Ho gaya ⭐

**C. Roz ke kaam (sab Sheet se)**
| Kaam | Kaise |
|---|---|
| Renew (mahina badhana) | `expiry` column me nayi date likh do |
| Payment nahi aaya / misuse | Row select → **🚫 block** (6 ghante ke andar premium band) |
| Customer ne naya computer liya | Row select → **💻 device reset** |
| 2 computer allow karne | `maxDevices` me `2` likh do |
| Kaun active hai | `lastCheck` column dekho |

**Kitna "full proof" hai — imaandaar jawab**
- ✅ Nakli key nahi ban sakti (key sirf aapki Sheet me hai)
- ✅ Ek key doston me share nahi hogi (device lock)
- ✅ Block / expiry turant aapke control me
- ✅ Internet band karke hamesha free me premium nahi chalega (48 ghante ke baad free)
- ⚠️ Koi bhi software jo user ke computer par chalta hai, use ek expert programmer code
  badal kar crack kar sakta hai — Chrome extension ka code chhupaya nahi ja sakta.
  Aam customer ke liye ye bahut mazboot hai; agar kabhi crack hua version dikhe, to us
  waqt "server-side features" (jaise message templates server se aana) jod sakte hain.

## 5. Folder structure (learning ke liye)

```
wa-smart-sender/
├── manifest.json        # Extension ka "ID card": naam, permissions, kaunsi file kahan chalegi
├── shared/
│   ├── config.js        # Plans, presets, WhatsApp selectors, server URL
│   ├── utils.js         # Random delay, spintax, phone format, CSV parse
│   └── license.js       # Server se key check, device ID
├── background.js        # Har 6 ghante license dobara check karta hai
├── content/
│   └── content.js       # ENGINE: WhatsApp tab ke andar chalta hai, message bhejta hai
├── popup/
│   ├── popup.html       # Icon dabane par dikhne wali window
│   ├── popup.css        # Design
│   └── popup.js         # Buttons, settings, progress dikhana
└── server/
    └── Code.gs          # Google Apps Script — aapka license server (Sheet me paste hota hai)
```

**Data flow:** `popup.js` → job ko `chrome.storage` me save → `content.js` storage dekhta hai →
wait → chat kholta hai → send → result storage me → popup live progress dikhata hai.

Debug: WhatsApp tab me `F12` → Console → `[WA Smart Sender]` wale logs dekho.

---

## 6. WhatsApp UI badal gaya / "Send click fail" aa raha hai?

WhatsApp apna HTML time-time par badalta hai. Fix:
1. WhatsApp Web me kisi chat ka **Send button** par right-click → **Inspect**.
2. Uska `aria-label` ya `data-icon` dekho.
3. `shared/config.js` → `SELECTORS.sendButton` list me sabse upar naya selector jodo.
4. Extension reload karo.

---

## 7. Aage kya bana sakte ho (Roadmap)
- Image / PDF attachment bhejna
- Razorpay payment se apne aap key banna
- Multiple message templates (A/B rotation)
- Scheduled campaign (date/time par start)
- Google Sheets se contacts lena
