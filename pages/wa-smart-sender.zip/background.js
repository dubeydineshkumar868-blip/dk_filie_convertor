/* =====================================================================
 * background.js — Peeche chalne wala service worker
 * Kaam: har 6 ghante me premium license server se dobara check karna
 * ===================================================================== */

importScripts('shared/config.js', 'shared/license.js');

function schedule() {
  chrome.alarms.create('verify-license', { delayInMinutes: 1, periodInMinutes: 360 });
}

chrome.runtime.onInstalled.addListener(schedule);
chrome.runtime.onStartup.addListener(schedule);

chrome.alarms.onAlarm.addListener(function (a) {
  if (a.name === 'verify-license') LIC.verify();
});
