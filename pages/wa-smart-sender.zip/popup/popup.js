/* =====================================================================
 * popup.js — Extension icon click karne par jo window khulti hai
 * Yeh sirf UI hai: settings leti hai, job storage me save karti hai,
 * progress dikhati hai. Asli sending content.js karta hai.
 * ===================================================================== */

var $ = function (id) { return document.getElementById(id); };
var tier = WSS.TIERS.free;
var currentJob = null;
var currentStats = null;
var timer = null;

var SETTING_FIELDS = ['minDelay', 'maxDelay', 'batchMin', 'batchMax', 'breakMin', 'breakMax',
  'dailyLimit', 'startHour', 'endHour'];

/* ---------------- UI helpers ---------------- */
function toast(msg, isErr) {
  var t = $('toast');
  t.textContent = msg;
  t.className = 'toast show' + (isErr ? ' err' : '');
  clearTimeout(t._h);
  t._h = setTimeout(function () { t.className = 'toast'; }, 2600);
}

document.querySelectorAll('.tabs button').forEach(function (b) {
  b.addEventListener('click', function () {
    document.querySelectorAll('.tabs button').forEach(function (x) { x.classList.remove('active'); });
    document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('active'); });
    b.classList.add('active');
    $('tab-' + b.dataset.tab).classList.add('active');
  });
});

/* ---------------- Load ---------------- */
async function load() {
  var d = await chrome.storage.local.get(['license', 'draft', 'job', 'stats', 'blocklist']);
  tier = WSS.tierFromLicense(d.license);
  renderLicense(d.license);
  LIC.deviceId().then(function (id) { $('deviceId').textContent = id; });
  if (d.license && d.license.key) LIC.verify(); // taaza status server se (result storage se aayega)
  fillDraft(d.draft || {});
  $('blocklist').value = (d.blocklist || []).join('\n');
  applyTier();
  currentJob = d.job || null;
  currentStats = d.stats || null;
  updateContactInfo();
  renderJob();
}

function fillDraft(draft) {
  var preset = WSS.PRESETS[tier.id];
  var s = Object.assign({}, preset, draft.settings || {});
  $('contacts').value = draft.contacts || '';
  $('message').value = draft.message || '';
  $('countryCode').value = s.countryCode || '91';
  SETTING_FIELDS.forEach(function (f) { $(f).value = s[f]; });
  $('useHours').checked = !!s.useHours;
  $('typingSim').checked = !!s.typingSim;
  $('optOut').checked = s.optOut !== false;
  $('optOutText').value = s.optOutText || 'Reply STOP to unsubscribe';
}

function applyTier() {
  var premium = tier.id === 'premium';
  $('tierBadge').textContent = tier.label;
  $('tierBadge').className = 'badge ' + tier.id;
  document.querySelectorAll('[data-premium]').forEach(function (el) { el.disabled = !premium; });
  document.querySelectorAll('[data-premium-lock]').forEach(function (el) { el.hidden = premium; });

  if (!premium) {
    // Free: safe preset dikhao
    var p = WSS.PRESETS.free;
    ['minDelay', 'maxDelay', 'batchMin', 'batchMax', 'breakMin', 'breakMax', 'startHour', 'endHour']
      .forEach(function (f) { $(f).value = p[f]; });
    $('useHours').checked = false;
    $('typingSim').checked = false;
  }
  $('dailyLimit').max = tier.dailyLimitMax;
  if (+$('dailyLimit').value > tier.dailyLimitMax) $('dailyLimit').value = tier.dailyLimitMax;
  $('limitHint').textContent = tier.label + ': max ' + tier.dailyLimitMax + ' messages/day';
  $('spinHint').textContent = premium
    ? 'Variables: {{name}} • Spintax: {Hi|Hello|Namaste} = har message alag'
    : 'Variables: {{name}} • Spintax {Hi|Hello} sirf Premium me';
}

/* ---------------- Settings ---------------- */
function readSettings() {
  var s = { countryCode: $('countryCode').value.replace(/\D/g, '') || '91' };
  SETTING_FIELDS.forEach(function (f) { s[f] = Number($(f).value); });
  s.useHours = $('useHours').checked;
  s.typingSim = $('typingSim').checked;
  s.optOut = $('optOut').checked;
  s.optOutText = $('optOutText').value.trim();

  if (tier.id !== 'premium') {
    var p = WSS.PRESETS.free;
    Object.assign(s, {
      minDelay: p.minDelay, maxDelay: p.maxDelay, batchMin: p.batchMin, batchMax: p.batchMax,
      breakMin: p.breakMin, breakMax: p.breakMax, useHours: false, typingSim: false
    });
  }
  s.dailyLimit = Math.min(Math.max(1, s.dailyLimit || 1), tier.dailyLimitMax);
  return s;
}

function validate(s) {
  if (s.minDelay < WSS.MIN_DELAY_FLOOR) return 'Min gap kam se kam ' + WSS.MIN_DELAY_FLOOR + ' sec rakho';
  if (s.maxDelay < s.minDelay + 10) return 'Max gap, Min se kam se kam 10 sec zyada ho';
  if (s.batchMin < 1 || s.batchMax < s.batchMin) return 'Batch size galat hai';
  if (s.breakMin < 1 || s.breakMax < s.breakMin) return 'Break minutes galat hain';
  if (s.useHours && (s.startHour < 0 || s.endHour > 24 || s.endHour <= s.startHour)) return 'Working hours galat hain';
  return null;
}

function getBlocklist() {
  return $('blocklist').value.split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean);
}

async function saveDraft() {
  await chrome.storage.local.set({
    draft: { contacts: $('contacts').value, message: $('message').value, settings: readSettings() },
    blocklist: getBlocklist()
  });
}

var draftTimer;
['contacts', 'message'].forEach(function (id) {
  $(id).addEventListener('input', function () {
    clearTimeout(draftTimer);
    draftTimer = setTimeout(saveDraft, 400);
    if (id === 'contacts') updateContactInfo();
  });
});

$('btnSaveSettings').addEventListener('click', async function () {
  var err = validate(readSettings());
  if (err) return toast(err, true);
  await saveDraft();
  toast('Settings saved ✅');
});

/* ---------------- Contacts ---------------- */
function parsed() {
  return U.parseContacts($('contacts').value, $('countryCode').value, getBlocklist());
}

function updateContactInfo() {
  var p = parsed();
  var parts = ['✅ ' + p.valid.length + ' valid'];
  if (p.invalid.length) parts.push('❌ ' + p.invalid.length + ' invalid');
  if (p.dupes) parts.push('♻ ' + p.dupes + ' duplicate');
  if (p.blocked) parts.push('🚫 ' + p.blocked + ' do-not-send');
  if (p.valid.length > tier.maxContacts) parts.push('⚠ ' + tier.label + ' limit ' + tier.maxContacts);
  $('contactInfo').textContent = parts.join(' • ');

  var chips = $('varChips');
  chips.innerHTML = '';
  p.keys.filter(function (k) { return k !== 'phone'; }).forEach(function (k) {
    var c = document.createElement('span');
    c.className = 'chip';
    c.textContent = '{{' + k + '}}';
    c.title = 'Click karke message me daalo';
    c.onclick = function () { insertAtCursor($('message'), '{{' + k + '}}'); };
    chips.appendChild(c);
  });
}

function insertAtCursor(el, txt) {
  var s = el.selectionStart, e = el.selectionEnd;
  el.value = el.value.slice(0, s) + txt + el.value.slice(e);
  el.focus();
  el.selectionStart = el.selectionEnd = s + txt.length;
  saveDraft();
}

$('btnCsv').addEventListener('click', function () { $('csvFile').click(); });
$('csvFile').addEventListener('change', function (e) {
  var f = e.target.files[0];
  if (!f) return;
  var r = new FileReader();
  r.onload = function () {
    $('contacts').value = r.result;
    updateContactInfo();
    saveDraft();
    toast('CSV import ho gaya');
  };
  r.readAsText(f);
});

function finalTemplate(s) {
  var t = $('message').value.trim();
  if (s.optOut && s.optOutText) t += '\n\n' + s.optOutText;
  return t;
}

$('btnPreview').addEventListener('click', function () {
  var p = parsed();
  var c = p.valid[0] || { name: 'Rahul', phone: '919876543210' };
  var pv = $('preview');
  pv.hidden = false;
  pv.textContent = U.buildMessage(finalTemplate(readSettings()), c, tier.spintax) || '(message khali hai)';
});

/* ---------------- Job controls ---------------- */
async function ensureWhatsAppTab() {
  var tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
  if (!tabs.length) {
    await chrome.tabs.create({ url: 'https://web.whatsapp.com/' });
    return;
  }
  var tab = tabs[0];
  await chrome.tabs.update(tab.id, { active: true });
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'PING' });
  } catch (e) {
    // Extension install hone se pehle tab khula tha -> reload karke script daalo
    await chrome.tabs.reload(tab.id);
  }
}

$('btnStart').addEventListener('click', async function () {
  var licNow = (await chrome.storage.local.get('license')).license;
  if (licNow && licNow.key) {
    await LIC.verify();
    tier = WSS.tierFromLicense((await chrome.storage.local.get('license')).license);
    applyTier();
  }
  var s = readSettings();
  var err = validate(s);
  if (err) return toast(err, true);

  var p = parsed();
  if (!p.valid.length) return toast('Koi valid contact nahi mila', true);
  if (p.valid.length > tier.maxContacts) {
    return toast(tier.label + ' plan me max ' + tier.maxContacts + ' contacts. Premium lo ya list chhoti karo.', true);
  }
  var template = finalTemplate(s);
  if (!$('message').value.trim()) return toast('Message likho', true);

  if (currentJob && (currentJob.status === 'running' || currentJob.status === 'paused')) {
    if (!confirm('Ek campaign pehle se chal raha hai. Use band karke naya shuru karein?')) return;
  }

  await saveDraft();
  var job = {
    id: Date.now(),
    status: 'running',
    contacts: p.valid,
    template: template,
    settings: s,
    index: 0,
    results: [],
    sent: 0,
    failed: 0,
    pending: null,
    sinceBreak: 0,
    nextBreakAt: U.randInt(s.batchMin, s.batchMax),
    nextAt: Date.now() + 3000,
    waitReason: 'Shuru ho raha hai…',
    createdAt: Date.now()
  };
  await chrome.storage.local.set({ job: job });
  await ensureWhatsAppTab();
  toast('Campaign start ✅ WhatsApp tab khula rakhein');
});

async function setStatus(status) {
  var job = (await chrome.storage.local.get('job')).job;
  if (!job) return;
  job.status = status;
  if (status === 'running') {
    job.pending = null;
    job.nextAt = Date.now() + 3000;
    job.waitReason = 'Resume ho raha hai…';
    await chrome.storage.local.set({ job: job });
    await ensureWhatsAppTab();
    return;
  }
  job.waitReason = status === 'paused' ? 'Paused' : 'Stopped';
  await chrome.storage.local.set({ job: job });
}

$('btnPause').addEventListener('click', function () { setStatus('paused'); });
$('btnResume').addEventListener('click', function () { setStatus('running'); });
$('btnStop').addEventListener('click', function () {
  if (confirm('Campaign band karein? (Report bachi rahegi)')) setStatus('stopped');
});

$('btnClear').addEventListener('click', async function () {
  if (currentJob && currentJob.status === 'running') return toast('Pehle Stop karein', true);
  await chrome.storage.local.remove('job');
  toast('Clear ho gaya');
});

$('btnReport').addEventListener('click', function () {
  if (!currentJob || !currentJob.results.length) return toast('Abhi koi report nahi hai', true);
  var rows = [['phone', 'name', 'status', 'reason', 'time']];
  currentJob.results.forEach(function (r) { rows.push([r.phone, r.name, r.status, r.reason, r.time]); });
  var csv = rows.map(function (r) { return r.map(U.csvEscape).join(','); }).join('\n');
  var url = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
  var a = document.createElement('a');
  a.href = url;
  a.download = 'wa-report-' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
});

/* ---------------- Render progress ---------------- */
function renderJob() {
  var j = currentJob;
  var today = currentStats && currentStats.date === U.todayKey() ? currentStats.sent : 0;
  var limit = j ? Math.min(j.settings.dailyLimit, tier.dailyLimitMax) : Number($('dailyLimit').value);
  $('stToday').textContent = today;
  $('stTodayLbl').textContent = 'Today/' + limit;

  var status = j ? j.status : 'idle';
  $('btnStart').hidden = status === 'running' || status === 'paused';
  $('btnPause').hidden = status !== 'running';
  $('btnResume').hidden = status !== 'paused';
  $('btnStop').hidden = !(status === 'running' || status === 'paused');

  if (!j) {
    $('statusText').textContent = 'Idle — contacts aur message daal ke Start karein';
    $('progressBar').style.width = '0%';
    ['stTotal', 'stSent', 'stFailed'].forEach(function (id) { $(id).textContent = 0; });
    $('countdown').textContent = '';
    return;
  }
  var total = j.contacts.length;
  $('stTotal').textContent = total;
  $('stSent').textContent = j.sent;
  $('stFailed').textContent = j.failed;
  $('progressBar').style.width = (total ? (j.index / total) * 100 : 0) + '%';

  var labels = { running: '🟢 Running', paused: '⏸ Paused', stopped: '⏹ Stopped', done: '✅ Done' };
  $('statusText').textContent = (labels[status] || status) + ' • ' + j.index + '/' + total +
    (j.waitReason ? ' • ' + j.waitReason : '');
  tickCountdown();
}

function tickCountdown() {
  var j = currentJob;
  if (j && j.status === 'running' && !j.pending && j.nextAt > Date.now()) {
    $('countdown').textContent = '⏱ ' + U.fmtDuration(j.nextAt - Date.now());
  } else {
    $('countdown').textContent = '';
  }
}

chrome.storage.onChanged.addListener(function (ch, area) {
  if (area !== 'local') return;
  if (ch.job) currentJob = ch.job.newValue || null;
  if (ch.stats) currentStats = ch.stats.newValue || null;
  if (ch.license) {
    tier = WSS.tierFromLicense(ch.license.newValue);
    renderLicense(ch.license.newValue);
    applyTier();
    updateContactInfo();
  }
  if (ch.job || ch.stats) renderJob();
});

/* ---------------- License ---------------- */
function renderLicense(lic) {
  var card = $('licenseCard');
  var msg = $('licenseMsg');
  if (lic && lic.key) $('licenseKey').value = lic.key;
  if (WSS.isPremium(lic)) {
    var exp = lic.expiry
      ? 'Valid till ' + new Date(lic.expiry).toLocaleDateString('en-IN') +
        ' (' + Math.max(0, Math.ceil((lic.expiry - Date.now()) / 86400000)) + ' din baaki)'
      : 'Lifetime ♾';
    card.hidden = false;
    card.innerHTML = '';
    var b = document.createElement('b');
    b.textContent = '⭐ Premium active' + (lic.name ? ' — ' + lic.name : '');
    var d = document.createElement('div');
    d.className = 'hint';
    d.textContent = exp;
    card.appendChild(b);
    card.appendChild(d);
    msg.textContent = '';
    return;
  }
  card.hidden = true;
  var reasons = {
    expired: '⌛ Plan khatam ho gaya — renew karein',
    blocked: '🚫 Key band kar di gayi hai',
    device: '💻 Ye key is computer par activate nahi hai',
    device_limit: '💻 Key dusre computer par chal rahi hai',
    invalid: '❌ Key galat hai'
  };
  if (lic && lic.key && lic.status === 'active') {
    msg.textContent = '📶 48 ghante se server check nahi hua — internet check karein';
  } else if (lic && lic.key) {
    msg.textContent = reasons[lic.status] || lic.message || 'Free plan';
  } else {
    msg.textContent = 'Abhi Free plan chal raha hai';
  }
}

$('btnActivate').addEventListener('click', async function () {
  var key = $('licenseKey').value.trim().toUpperCase();
  if (!/^WSS-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(key)) {
    return toast('Key ka format galat hai', true);
  }
  var btn = $('btnActivate');
  btn.disabled = true;
  btn.textContent = 'Checking…';
  try {
    var res = await LIC.activate(key);
    if (res.ok) toast('Premium activate ho gaya ⭐');
    else toast(res.message || 'Key valid nahi hai', true);
  } catch (e) {
    toast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Activate';
  }
});

$('btnDeactivate').addEventListener('click', async function () {
  if (!confirm('Is computer se Premium hatana hai? (Fir key dusre PC par laga sakte hain)')) return;
  await LIC.deactivate();
  $('licenseKey').value = '';
  toast('License hata diya — Free plan');
});

timer = setInterval(tickCountdown, 1000);
load();
