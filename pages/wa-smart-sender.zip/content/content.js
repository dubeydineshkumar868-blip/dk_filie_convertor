/* =====================================================================
 * content.js — WhatsApp Web tab ke andar chalne wala "engine"
 *
 * Kaam kaise hota hai (simple flow):
 *  1. Popup "job" ko chrome.storage me save karta hai (status = running)
 *  2. Yeh script job padhti hai, random gap ka wait karti hai
 *  3. Contact ka chat kholti hai: web.whatsapp.com/send?phone=..&text=..
 *     (yeh WhatsApp ka official click-to-chat link hai)
 *  4. Page load hone par message box me text aa jata hai -> "padhne/type"
 *     jitna pause -> Send button click
 *  5. Result save, agla random gap set, repeat
 *  Har step storage me save hota hai, isliye page reload/crash ke baad
 *  bhi job wahin se resume hota hai.
 * ===================================================================== */

(function () {
  if (window.__wssLoaded) return;
  window.__wssLoaded = true;

  var S = WSS.SELECTORS;
  var running = false;
  var log = function () {
    var a = Array.prototype.slice.call(arguments);
    a.unshift('%c[WA Smart Sender]', 'color:#25d366;font-weight:bold');
    console.log.apply(console, a);
  };

  /* ---------- storage helpers ---------- */
  async function getJob() { return (await chrome.storage.local.get('job')).job; }
  async function saveJob(job) { await chrome.storage.local.set({ job: job }); }

  async function getTier() {
    var lic = (await chrome.storage.local.get('license')).license;
    return WSS.tierFromLicense(lic);
  }

  async function getStats() {
    var stats = (await chrome.storage.local.get('stats')).stats;
    var today = U.todayKey();
    if (!stats || stats.date !== today) return { date: today, sent: 0 };
    return stats;
  }

  async function bumpStats() {
    var s = await getStats();
    s.sent++;
    await chrome.storage.local.set({ stats: s });
  }

  /* ---------- DOM helpers ---------- */
  function findAny(list) {
    for (var i = 0; i < list.length; i++) {
      var el = document.querySelector(list[i]);
      if (el) return el;
    }
    return null;
  }

  async function waitFor(fn, timeout, interval) {
    var end = Date.now() + timeout;
    while (Date.now() < end) {
      var r = fn();
      if (r) return r;
      await U.sleep(interval || 500);
    }
    return null;
  }

  // Lamba wait, lekin har second check karo ki user ne Stop/Pause to nahi kiya
  async function sleepUntil(ts) {
    while (Date.now() < ts) {
      await U.sleep(Math.min(1000, ts - Date.now()));
      var j = await getJob();
      if (!j || j.status !== 'running') return false;
    }
    return true;
  }

  function invalidDialog() {
    var all = document.querySelectorAll(S.dialog.join(','));
    for (var i = 0; i < all.length; i++) {
      if (S.invalidText.test(all[i].textContent || '')) return all[i];
    }
    return null;
  }

  function findSendButton() {
    var el = findAny(S.sendButton);
    if (!el) return null;
    return el.closest('button') || el.closest('[role="button"]') || el;
  }

  function pressEnter(box) {
    box.focus();
    ['keydown', 'keypress', 'keyup'].forEach(function (type) {
      box.dispatchEvent(new KeyboardEvent(type, {
        key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true
      }));
    });
  }

  function composeText() {
    var b = findAny(S.composeBox);
    return b ? (b.textContent || '').trim() : null;
  }

  /* ---------- 1 message bhejna (chat khul chuka hai) ---------- */
  async function sendOnPage(job, tier) {
    var ready = await waitFor(function () { return findAny(S.appReady); }, 90000);
    if (!ready) return { ok: false, reason: 'WhatsApp load nahi hua / QR login nahi hai' };

    var outcome = await waitFor(function () {
      var dlg = invalidDialog();
      if (dlg) return { type: 'invalid', dlg: dlg };
      var t = composeText();
      if (t) return { type: 'ready' };
      return null;
    }, 45000, 700);

    if (!outcome) return { ok: false, reason: 'Chat open nahi hua (timeout)' };

    if (outcome.type === 'invalid') {
      var okBtn = outcome.dlg.querySelector('button');
      if (okBtn) okBtn.click();
      return { ok: false, reason: 'Number WhatsApp par nahi hai / invalid' };
    }

    // Insaan jaisa pause: message "padhna / type karna"
    var pause = U.typingPauseMs(job.pending.text, tier.typingSim && job.settings.typingSim);
    job.waitReason = 'Typing… (' + U.fmtDuration(pause) + ')';
    await saveJob(job);
    if (!(await sleepUntil(Date.now() + pause))) return { stopped: true };

    var btn = findSendButton();
    if (btn) btn.click();
    else pressEnter(findAny(S.composeBox));

    var cleared = await waitFor(function () { return composeText() === ''; }, 15000, 400);
    if (!cleared) return { ok: false, reason: 'Send click fail — config.js me selectors update karein' };

    return { ok: true };
  }

  /* ---------- Main loop ---------- */
  async function runLoop() {
    while (true) {
      var job = await getJob();
      if (!job || job.status !== 'running') return;
      var tier = await getTier();
      var set = job.settings;

      // Sab contacts ho gaye?
      if (job.index >= job.contacts.length) {
        job.status = 'done';
        job.waitReason = 'Campaign complete ✅';
        job.pending = null;
        job.finishedAt = Date.now();
        await saveJob(job);
        log('Campaign complete');
        return;
      }

      var c = job.contacts[job.index];

      // (A) Hum is contact ka chat khol chuke hain -> ab bhejo
      if (job.pending && job.pending.phone === c.phone) {
        log('Sending to', c.phone);
        var res = await sendOnPage(job, tier);
        job = await getJob();
        if (!job) return;

        if (res.stopped) {
          job.pending = null;
          await saveJob(job);
          return;
        }

        job.results.push({
          phone: c.phone,
          name: c.name || '',
          status: res.ok ? 'sent' : 'failed',
          reason: res.reason || '',
          time: new Date().toLocaleString()
        });
        job.index++;
        job.pending = null;
        if (res.ok) { job.sent++; await bumpStats(); } else { job.failed++; }
        log(res.ok ? 'Sent ✓' : 'Failed ✗ ' + res.reason);

        // Agla random gap
        job.sinceBreak = (job.sinceBreak || 0) + 1;
        var delay, reason;
        if (job.sinceBreak >= job.nextBreakAt) {
          delay = U.randInt(set.breakMin * 60, set.breakMax * 60) * 1000 + U.randInt(0, 999);
          reason = 'Batch break ☕ (insaan jaisa aaram)';
          job.sinceBreak = 0;
          job.nextBreakAt = U.randInt(set.batchMin, set.batchMax);
        } else {
          delay = U.humanDelayMs(set.minDelay, set.maxDelay);
          reason = 'Random gap';
        }
        job.nextAt = Date.now() + delay;
        job.waitReason = reason;
        await saveJob(job);
        continue;
      }

      // (B) Daily limit
      var stats = await getStats();
      var limit = Math.min(set.dailyLimit, tier.dailyLimitMax);
      if (stats.sent >= limit) {
        var t = U.tomorrowStart(set.useHours ? set.startHour : 9);
        if (job.nextAt < t) {
          job.nextAt = t;
          job.waitReason = 'Aaj ka limit poora (' + limit + ') — kal auto resume';
          await saveJob(job);
        }
      }

      // (C) Working hours (Premium)
      if (tier.workingHours && set.useHours) {
        var allowed = U.nextAllowedTime(Math.max(Date.now(), job.nextAt), set.startHour, set.endHour);
        if (allowed > job.nextAt) {
          job.nextAt = allowed;
          job.waitReason = 'Working hours ke bahar — ' + set.startHour + ':00 par resume';
          await saveJob(job);
        }
      }

      // (D) Wait
      if (Date.now() < job.nextAt) {
        if (!(await sleepUntil(job.nextAt))) return;
        continue;
      }

      // (E) Agle contact ka chat kholo
      var text = U.buildMessage(job.template, c, tier.spintax);
      job.pending = { phone: c.phone, text: text, at: Date.now() };
      job.waitReason = 'Chat khol rahe hain…';
      await saveJob(job);
      location.href = 'https://web.whatsapp.com/send?phone=' + c.phone +
        '&text=' + encodeURIComponent(text);
      return; // page reload hoga, script phir se chalegi aur (A) step karegi
    }
  }

  function kick() {
    if (running) return;
    running = true;
    runLoop()
      .catch(function (e) { console.error('[WA Smart Sender]', e); })
      .finally(function () { running = false; });
  }

  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area === 'local' && ch.job && ch.job.newValue && ch.job.newValue.status === 'running') kick();
  });

  chrome.runtime.onMessage.addListener(function (msg, sender, reply) {
    if (msg && msg.type === 'PING') reply({ ok: true });
  });

  log('Engine ready v' + WSS.VERSION);
  kick();
})();
